package cn.shuangzeit.szweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SzwebApplicationTests {

	@Test
	void contextLoads() {
	}

}

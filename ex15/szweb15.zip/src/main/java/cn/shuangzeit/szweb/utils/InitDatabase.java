package cn.shuangzeit.szweb.utils;

import cn.shuangzeit.szweb.domain.Menu;
import cn.shuangzeit.szweb.domain.Notice;
import cn.shuangzeit.szweb.domain.User;
import cn.shuangzeit.szweb.dto.Role;
import lombok.val;
import org.bson.types.ObjectId;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;


@Component //该注解使Spring框架自动为该类创建一个新Bean
public class InitDatabase {
    @Bean
        //该注解使Spring框架自动为方法的返回值创建一个Bean
    CommandLineRunner init(MongoOperations operations) {
        return args -> {
            if (operations.findAll(Notice.class).isEmpty()) {
                operations.insert(Notice.builder().title("通知通告标题一").content("通知通告内容一 ").hit(0).updateTime(LocalDateTime.now())
                        .updateUser("admin").build());
                operations.insert(Notice.builder().title("通知通告标题二").content("通知通告内容二 ").hit(0).updateTime(LocalDateTime.now())
                        .updateUser("admin").build());
                operations.insert(Notice.builder().title("通知通告标题三").content("通知通告内容三 ").hit(0).updateTime(LocalDateTime.now())
                        .updateUser("admin").build());
            }
            if (operations.findAll(User.class).isEmpty()) {
                //原始密码：12345678，前端加密：7e6a4309ddf6e8866679f61ace4f621b0e3455ebac2e831a60f13cd1
                operations.insert(User.builder().username("admin").password("OWO1pspI0T9QyThtjQ2fPm6xQdXIGZSY1GPh5eb5ZL0=").name("羽过天晴").email("ygtq@haibusiness.com").phone("19999999999").enabled(true).authorities(List.of(Role.ROLE_ADMIN)).createTime(LocalDateTime.now()).updateTime(LocalDateTime.now()).build());
                operations.insert(User.builder().username("test").password("OWO1pspI0T9QyThtjQ2fPm6xQdXIGZSY1GPh5eb5ZL0=").name("张三").email("zhangsan@haibusiness.com").phone("18888888888").enabled(true).authorities(List.of(Role.ROLE_USER)).createTime(LocalDateTime.now()).updateTime(LocalDateTime.now()).build());
            }
            if (operations.findAll(Menu.class).isEmpty()) {
                //val user=operations.findOne(new Query(Criteria.where("username").is("admin")),User.class);
                operations.insert(Menu.builder().name("menu").icon("line_style").authorities(List.of(Role.ROLE_ADMIN)).title("菜单管理").updateUser("admin").updateTime(LocalDateTime.now()).createTime(LocalDateTime.now()).build());
                operations.insert(Menu.builder().name("user").icon("people").authorities(List.of(Role.ROLE_ADMIN)).title("用户管理").updateUser("admin").updateTime(LocalDateTime.now()).createTime(LocalDateTime.now()).build());
                val menu3_1 = Menu.builder().id(new ObjectId().toString()).name("introduction").icon("assignment").authorities(List.of(Role.ROLE_PUBLIC)).title("学院简介").parent("学院概况").updateUser("admin").updateTime(LocalDateTime.now()).createTime(LocalDateTime.now()).build();
                val menu3_2 = Menu.builder().id(new ObjectId().toString()).name("teacher").icon("assignment_ind").authorities(List.of(Role.ROLE_PUBLIC)).title("师资队伍").parent("学院概况").updateUser("admin").updateTime(LocalDateTime.now()).createTime(LocalDateTime.now()).build();
                val menu3_3 = Menu.builder().id(new ObjectId().toString()).name("specialty").icon("perm_data_setting").authorities(List.of(Role.ROLE_PUBLIC)).title("专业设置").parent("学院概况").updateUser("admin").updateTime(LocalDateTime.now()).createTime(LocalDateTime.now()).build();
                operations.insert(Menu.builder().name("overview").icon("dvr").items(List.of(menu3_1, menu3_2, menu3_3)).authorities(List.of(Role.ROLE_PUBLIC)).title("学院概况").updateUser("admin").updateTime(LocalDateTime.now()).createTime(LocalDateTime.now()).build());
                val menu4_1 = Menu.builder().id(new ObjectId().toString()).name("teaching").icon("local_library").authorities(List.of(Role.ROLE_PUBLIC)).title("教学活动").parent("教研工作").updateUser("admin").updateTime(LocalDateTime.now()).createTime(LocalDateTime.now()).build();
                val menu4_2 = Menu.builder().id(new ObjectId().toString()).name("research").icon("list_alt").authorities(List.of(Role.ROLE_PUBLIC)).title("科研情况").parent("教研工作").updateUser("admin").updateTime(LocalDateTime.now()).createTime(LocalDateTime.now()).build();
                operations.insert(Menu.builder().name("teachingResearch").icon("school").items(List.of(menu4_1, menu4_2)).authorities(List.of(Role.ROLE_PUBLIC)).title("教研工作").updateUser("admin").updateTime(LocalDateTime.now()).createTime(LocalDateTime.now()).build());
                val menu5_1 = Menu.builder().id(new ObjectId().toString()).name("member").icon("outlined_flag").authorities(List.of(Role.ROLE_PUBLIC)).title("团学活动").parent("团学工作").updateUser("admin").updateTime(LocalDateTime.now()).createTime(LocalDateTime.now()).build();
                val menu5_2 = Menu.builder().id(new ObjectId().toString()).name("student").icon("how_to_reg").authorities(List.of(Role.ROLE_PUBLIC)).title("优秀学子").parent("团学工作").updateUser("admin").updateTime(LocalDateTime.now()).createTime(LocalDateTime.now()).build();
                operations.insert(Menu.builder().name("memberStudent").icon("recent_actors").items(List.of(menu5_1, menu5_2)).authorities(List.of(Role.ROLE_PUBLIC)).title("团学工作").updateUser("admin").updateTime(LocalDateTime.now()).createTime(LocalDateTime.now()).build());
                val menu6_1 = Menu.builder().id(new ObjectId().toString()).name("training").icon("account_balance").authorities(List.of(Role.ROLE_PUBLIC)).title("校内实训").parent("就业情况").updateUser("admin").updateTime(LocalDateTime.now()).createTime(LocalDateTime.now()).build();
                val menu6_2 = Menu.builder().id(new ObjectId().toString()).name("practice").icon("event").authorities(List.of(Role.ROLE_PUBLIC)).title("定岗实习").parent("就业情况").updateUser("admin").updateTime(LocalDateTime.now()).createTime(LocalDateTime.now()).build();
                val menu6_3 = Menu.builder().id(new ObjectId().toString()).name("employmentInfor").icon("library_books").authorities(List.of(Role.ROLE_PUBLIC)).title("就业信息").parent("就业情况").updateUser("admin").updateTime(LocalDateTime.now()).createTime(LocalDateTime.now()).build();
                operations.insert(Menu.builder().name("employment").icon("card_travel").items(List.of(menu6_1, menu6_2, menu6_3)).authorities(List.of(Role.ROLE_PUBLIC)).title("就业情况").updateUser("admin").updateTime(LocalDateTime.now()).createTime(LocalDateTime.now()).build());
                val menu7_1 = Menu.builder().id(new ObjectId().toString()).name("enterprise").icon("ballot").authorities(List.of(Role.ROLE_PUBLIC)).title("企业情况").parent("校企合作").updateUser("admin").updateTime(LocalDateTime.now()).createTime(LocalDateTime.now()).build();
                val menu7_2 = Menu.builder().id(new ObjectId().toString()).name("cooperationInfor").icon("cached").authorities(List.of(Role.ROLE_PUBLIC)).title("合作动态").parent("校企合作").updateUser("admin").updateTime(LocalDateTime.now()).createTime(LocalDateTime.now()).build();
                operations.insert(Menu.builder().name("collaboration").icon("business").items(List.of(menu7_1, menu7_2)).authorities(List.of(Role.ROLE_PUBLIC)).title("校企合作").updateUser("admin").updateTime(LocalDateTime.now()).createTime(LocalDateTime.now()).build());
                operations.insert(Menu.builder().name("download").icon("save_alt").authorities(List.of(Role.ROLE_PUBLIC)).title("下载中心").updateUser("admin").updateTime(LocalDateTime.now()).createTime(LocalDateTime.now()).build());
                operations.insert(Menu.builder().name("carousel").icon("photo_library").authorities(List.of(Role.ROLE_ADMIN, Role.ROLE_USER)).title("图片新闻").updateUser("admin").updateTime(LocalDateTime.now()).createTime(LocalDateTime.now()).build());
                operations.insert(Menu.builder().name("notice").icon("cast").authorities(List.of(Role.ROLE_ADMIN, Role.ROLE_USER)).title("通知通告").updateUser("admin").updateTime(LocalDateTime.now()).createTime(LocalDateTime.now()).build());
                operations.insert(Menu.builder().name("dynamic").icon("cast_connected").authorities(List.of(Role.ROLE_ADMIN, Role.ROLE_USER)).title("学院动态").updateUser("admin").updateTime(LocalDateTime.now()).createTime(LocalDateTime.now()).build());
                operations.insert(Menu.builder().name("graduate").icon("movie_filter").authorities(List.of(Role.ROLE_ADMIN, Role.ROLE_USER)).title("校友风采").updateUser("admin").updateTime(LocalDateTime.now()).createTime(LocalDateTime.now()).build());
            }

        };
    }
}
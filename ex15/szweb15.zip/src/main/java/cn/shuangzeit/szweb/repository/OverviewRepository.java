package cn.shuangzeit.szweb.repository;

import cn.shuangzeit.szweb.domain.Overview;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface OverviewRepository extends ReactiveMongoRepository<Overview,String> {

    Flux<Overview> findByTypeAndTitleLikeOrderByUpdateTimeDesc(String type, String title);


}



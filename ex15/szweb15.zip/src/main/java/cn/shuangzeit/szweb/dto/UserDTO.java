package cn.shuangzeit.szweb.dto;

import lombok.Data;

import java.util.List;

@Data
public class UserDTO {
    private String username;
    private String password;
    private String name;
    private String email;
    private String mobile;
    private String avatar;
    private List<Role> roles;
}
package cn.shuangzeit.szweb.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Value;

import java.util.List;

@Value
public class PageSupport<T> {

    public static final int FIRST_PAGE_NUM = 0;
    public static final int DEFAULT_PAGE_SIZE = 20;

    private List<T> content;
    private int pageNumber;
    private int pageSize;
    private long totalElements;
    private String title;
    private String subTitle;

    @JsonProperty //该注解让所标注方法的返回值成为JSON对象的属性
    public long totalPages() {
        return pageSize > 0 ? (totalElements - 1) / pageSize + 1 : 0;
    }

    @JsonProperty
    public boolean first() {
        return pageNumber == FIRST_PAGE_NUM;
    }

    @JsonProperty
    public boolean last() {
        return (pageNumber + 1) * pageSize >= totalElements;
    }

}

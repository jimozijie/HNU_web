package cn.shuangzeit.szweb.repository;

import cn.shuangzeit.szweb.domain.TeachingResearch;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import reactor.core.publisher.Flux;

public interface TeachingResearchRepository extends ReactiveMongoRepository<TeachingResearch,String> {
    Flux<TeachingResearch> findByTypeAndTitleLikeOrderByUpdateTimeDesc(String type,String title);
}

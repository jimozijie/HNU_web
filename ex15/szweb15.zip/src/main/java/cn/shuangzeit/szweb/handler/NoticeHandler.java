package cn.shuangzeit.szweb.handler;

import cn.shuangzeit.szweb.domain.Menu;
import cn.shuangzeit.szweb.domain.Notice;
import cn.shuangzeit.szweb.dto.PageSupport;
import cn.shuangzeit.szweb.exception.ServerException;
import cn.shuangzeit.szweb.repository.MenuRepository;
import cn.shuangzeit.szweb.repository.NoticeRepository;
import lombok.AllArgsConstructor;
import lombok.val;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Mono;
import reactor.util.function.Tuple2;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import static cn.shuangzeit.szweb.dto.PageSupport.DEFAULT_PAGE_SIZE;
import static cn.shuangzeit.szweb.dto.PageSupport.FIRST_PAGE_NUM;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.web.reactive.function.server.ServerResponse.notFound;
import static org.springframework.web.reactive.function.server.ServerResponse.ok;

@Component
@AllArgsConstructor
public class NoticeHandler {
    private final NoticeRepository noticeRepository;
    private final MenuRepository menuRepository;

    /**
     * 分页按关键字查询通知通告
     *
     * @param request
     * @return
     */
    public Mono<ServerResponse> getEntityPage(ServerRequest request) {
        val pageIndex = request.queryParam("pageIndex").map(Integer::parseInt).orElse(FIRST_PAGE_NUM);
        val pageSize = request.queryParam("pageSize").map(Integer::parseInt).orElse(DEFAULT_PAGE_SIZE);
        val title = request.queryParam("title").orElse("");
        val menuMono = menuRepository.findByName("notice");
        val noticesFlux = noticeRepository.findByTitleLikeOrderByUpdateTimeDesc(title);
        val pageContent = Mono.
                zip(menuMono, noticesFlux.collectList())
                .map((Tuple2<Menu, List<Notice>> data) -> {
                    val name = data.getT1().getTitle();
                    val list = data.getT2();
                    return new PageSupport<>(
                            list.stream()
                                    .skip(pageIndex * pageSize)
                                    .limit(pageSize)
                                    .collect(Collectors.toList()),
                            pageSize, pageSize, list.size(), name, null);
                });
        return ok().contentType(APPLICATION_JSON).body(pageContent, PageSupport.class);

    }

    /**
     * 创建通知通告
     *
     * @param request
     * @return
     */
    @PreAuthorize("hasRole('ROLE_ADMIN') or hasRole('ROLE_USER')")
    public Mono<ServerResponse> createNotice(ServerRequest request) {
        return request.bodyToMono(Notice.class).flatMap(notice -> {
            notice.setUpdateUser("admin");
            notice.setUpdateTime(LocalDateTime.now());
            notice.setHit(0);
            return ok().contentType(APPLICATION_JSON)
                    .body(this.noticeRepository.save(notice), Notice.class);
        });
    }

    /**
     * 更新阅读次数
     *
     * @param request
     * @return
     */
    public Mono<ServerResponse> addReading(ServerRequest request) {
        val id = request.pathVariable("id");
        return noticeRepository.findById(id).flatMap(result -> {
            result.setHit(result.getHit() + 1);
            return noticeRepository.save(result).then(ok().bodyValue("更新成功！"));
        });

    }

    /**
     * 更新通知通告信息
     *
     * @param request
     * @return
     */
    @PreAuthorize("hasRole('ROLE_ADMIN') or hasRole('ROLE_USER')")
    public Mono<ServerResponse> updateNotice(ServerRequest request) {
        return request.bodyToMono(Notice.class).flatMap(notice -> noticeRepository.findById(notice.getId()).flatMap(old -> {
            old.setUpdateTime(LocalDateTime.now());
            old.setUpdateUser("admin");
            old.setTitle(notice.getTitle());
            old.setContent(notice.getContent());
            old.setHit(notice.getHit());
            return ok().contentType(APPLICATION_JSON)
                    .body(this.noticeRepository.save(old), Notice.class);
        }).switchIfEmpty(Mono.error(new ServerException(900,"您要更新的信息不存在！"))));

    }

    /**
     * 根据id删除通知通告
     *
     * @param request
     * @return
     */
    @PreAuthorize("hasRole('ROLE_ADMIN') or hasRole('ROLE_USER')")
    public Mono<ServerResponse> deleteNoticeById(ServerRequest request) {
        val id = request.pathVariable("id");
        return this.noticeRepository.existsById(id).flatMap(result -> {
                    if (result) {
                        return this.noticeRepository
                                .deleteById(id)
                                .then(ok().build());
                    } else {
                        return notFound().build();
                    }
                }
        );
    }

    /**
     * 根据id获取通知通告
     *
     * @param request
     * @return
     */
    public Mono<ServerResponse> getNotice(ServerRequest request) {
        return noticeRepository.findById(request.pathVariable("id"))
                .flatMap(notice -> ok().contentType(APPLICATION_JSON).bodyValue(notice))
                .switchIfEmpty(Mono.error(new ServerException(900, "您要查找的信息不存在！")));
    }
}
package cn.shuangzeit.szweb.repository;

import cn.shuangzeit.szweb.domain.Graduate;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;

public interface GraduateRepository extends ReactiveMongoRepository<Graduate,String> {
}

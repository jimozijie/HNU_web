package cn.shuangzeit.szweb.dto;

import java.util.List;

public record HomeItem(
        String name,
        String type,
        String icon,
        String url,
        List items
) {
}
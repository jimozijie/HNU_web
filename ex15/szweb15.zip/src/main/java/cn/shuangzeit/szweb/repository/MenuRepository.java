package cn.shuangzeit.szweb.repository;

import cn.shuangzeit.szweb.domain.Menu;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface MenuRepository extends ReactiveMongoRepository<Menu, String> {
    Flux<Menu> findByTitleLikeOrderByUpdateTimeDesc(String title);
    Mono<Menu> findByName(String name);
}
package cn.shuangzeit.szweb.repository;

import cn.shuangzeit.szweb.domain.Notice;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import reactor.core.publisher.Flux;


public interface NoticeRepository extends ReactiveMongoRepository<Notice, String> {
    Flux<Notice> findByTitleLikeOrderByUpdateTimeDesc(String title);
}
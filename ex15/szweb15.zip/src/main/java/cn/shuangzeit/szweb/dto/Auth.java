package cn.shuangzeit.szweb.dto;

import lombok.Data;

@Data
public class Auth {
    private String username;
    private String password;
}
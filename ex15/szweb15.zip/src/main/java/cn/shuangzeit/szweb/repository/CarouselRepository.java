package cn.shuangzeit.szweb.repository;

import cn.shuangzeit.szweb.domain.Carousel;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;

public interface CarouselRepository extends ReactiveMongoRepository<Carousel,String> {
}
